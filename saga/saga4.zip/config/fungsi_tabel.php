
<script>
    $(document).ready(function() {
        $('#example').DataTable();
    } );
</script>