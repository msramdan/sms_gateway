Testing
=======

Gammu comes with quite big test suite. It covers some basic low level
functions, handling replies from the phone and also does testing of command
line utilities and SMSD.

.. seealso:: See :ref:`testing` for more details.
